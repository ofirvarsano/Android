package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        Bitmap bmp = null;

        //get passed variables
        Intent intent = getIntent();
        String amount = intent.getStringExtra("amount");
        String payments = intent.getStringExtra("payments");
        Boolean isILS = getIntent().getExtras().getBoolean("isILS");
        Boolean isPayments = getIntent().getExtras().getBoolean("isPayments");
        Boolean isCurrency = getIntent().getExtras().getBoolean("isCurrency");
        Boolean isSignature = getIntent().getExtras().getBoolean("isSignature");

        if(isSignature)
        {
            byte[] byteArray = getIntent().getByteArrayExtra("sig");
            bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        }

        //Amount Display
        TextView amountView = (TextView) findViewById(R.id.amounttxt2);
        amountView.setText(amountView.getText() + amount);

        //Payments Display
        TextView paymentsView = (TextView) findViewById(R.id.paymenttxt);
        if(isPayments)
        {
            paymentsView.setVisibility(View.VISIBLE);
            paymentsView.setText(paymentsView.getText() + payments);
        }
        else
        {
            paymentsView.setVisibility(View.GONE);
        }

        //Currency Display
        TextView currencyView = (TextView) findViewById(R.id.currencytxt);
        if(isCurrency)
        {
            currencyView.setVisibility(View.VISIBLE);
            if(isILS)
                currencyView.setText(currencyView.getText() + "ILS");
            else
                currencyView.setText(currencyView.getText() + "USD");
        }
        else
        {
            currencyView.setVisibility(View.GONE);
        }

        //Signature Display
        View signatureLayout = (View) findViewById(R.id.signatureLayout2);
        if(isSignature)
        {
            signatureLayout.setVisibility(View.VISIBLE);
            ImageView signatureImage = (ImageView) findViewById(R.id.signatureImage);
            if(bmp != null)
                signatureImage.setImageBitmap(bmp);
        }
        else
        {
            signatureLayout.setVisibility(View.GONE);
        }

        //Finish
        Button buttonFinish = (Button) findViewById(R.id.buttonFinish);
        buttonFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = getBaseContext().getPackageManager()
                        .getLaunchIntentForPackage( getBaseContext().getPackageName() );
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                finish();
                startActivity(i);
            }
        });
    }
}