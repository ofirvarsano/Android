package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

import com.github.gcacace.signaturepad.views.SignaturePad;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    //Bitmap sig;

    boolean isSignature = true;
    boolean isSignatureEnabled = true;

    boolean isCurrencyEnabled = true;

    boolean isPayments = true;
    boolean isPaymentsEnabled = true;

    boolean isILS = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //payment list box initialization
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        //list box between 1-12
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.payments));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        //signature switch
        Switch signature = (Switch) findViewById(R.id.signatureSwitch);
        signature.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isSignature = true;
                } else {
                    isSignature = false;
                }
            }
        });

        //payments switch
        Switch payments = (Switch) findViewById(R.id.paymentSwitch);
        payments.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isPayments = true;
                    spinner.setEnabled(true);
                } else {
                    isPayments = false;
                    spinner.setEnabled(false);
                }
            }
        });

        //Submit
        //I know there is a way to check all buttons is one OnClickListener but I learned it a long time ago and I forgot
        Button submitButton = (Button) findViewById(R.id.buttonSubmit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isSignature)
                {
                    //openSignatureFrame();
                    openReceiptActivity();
                }
                else
                {
                    openReceiptActivity();
                }

            }
        });

        //Exit
        Button buttonExit = (Button) findViewById(R.id.buttonExit);
        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //restartApp();
                finishAndRemoveTask();
            }
        });

        //close settings
        Button CloseSettingsButton = (Button) findViewById(R.id.closeSettingsButton);
        CloseSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View settingsLayout = (View) findViewById(R.id.settingsLayout);
                settingsLayout.setVisibility(View.GONE);
            }
        });

        //open settings
        Button OpenSettingsButton = (Button) findViewById(R.id.settingsButton);
        OpenSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View settingsLayout = (View) findViewById(R.id.settingsLayout);
                settingsLayout.setVisibility(View.VISIBLE);
            }
        });

        //payments settings
        Switch paymentsSettingsButton = (Switch) findViewById(R.id.settingsPayments);
        paymentsSettingsButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                View paymentsLayout = (View) findViewById(R.id.paymentsLayout);
                if (isChecked) {
                    isPayments = true;
                    isPaymentsEnabled = true;
                    paymentsLayout.setVisibility(View.VISIBLE);
                } else {
                    isPayments = false;
                    isPaymentsEnabled = false;
                    paymentsLayout.setVisibility(View.GONE);
                }
            }
        });

        //currency settings
        Switch currencySettingsButton = (Switch) findViewById(R.id.settingsCurrency);
        currencySettingsButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                View currencyLayout = (View) findViewById(R.id.currencyLayout);
                if (isChecked) {
                    isCurrencyEnabled = true;
                    currencyLayout.setVisibility(View.VISIBLE);
                } else {
                    isCurrencyEnabled = false;
                    currencyLayout.setVisibility(View.GONE);
                }
            }
        });

        //signature settings
        Switch signatureSettingsButton = (Switch) findViewById(R.id.settingsSignature);
        signatureSettingsButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                View signatureLayout = (View) findViewById(R.id.signatureLayout);
                if (isChecked) { //signatureLayout
                    isSignature = true;
                    isSignatureEnabled = true;
                    signatureLayout.setVisibility(View.VISIBLE);
                } else {
                    isSignature = false;
                    isSignatureEnabled = false;
                    signatureLayout.setVisibility(View.GONE);
                }
            }
        });

        //signature frame
        /*
        Button submitSigButton = (Button) findViewById(R.id.submitSigButton);
        submitSigButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openReceiptActivity();
            }
        });

        Button cancelButton = (Button) findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignaturePad signaturePad = findViewById(R.id.signaturePad);
                signaturePad.clear();
                View signatureFrame = (View) findViewById(R.id.signatureFrame);
                signatureFrame.setVisibility(View.GONE);
            }
        });
         */
    }

    public void openReceiptActivity() {
        EditText amounttxt = (EditText)findViewById(R.id.amounttxt);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        //Toggle Handle
        MaterialButtonToggleGroup materialButtonToggleGroup = findViewById(R.id.toggleButtonGroup);
        int buttonId = materialButtonToggleGroup.getCheckedButtonId();
        MaterialButton button = materialButtonToggleGroup.findViewById(buttonId);
        if(buttonId == R.id.buttonUSD)
        {
            isILS = false;
        }

        //Amount Handle
        String amount = "0";
        amount = amounttxt.getText().toString();

        String spinnerValue = spinner.getSelectedItem().toString();

        Intent intent = new Intent(this, ReceiptActivity.class);
        intent.putExtra("amount", amount);
        //if paymentSwitch
        intent.putExtra("payments", spinnerValue);
        //if currency
        intent.putExtra("isILS", isILS);
        intent.putExtra("isPayments", isPayments);
        intent.putExtra("isCurrency", isCurrencyEnabled);
        intent.putExtra("isSignature", isSignature);

        /*
        if(isSignature)
        {
            SignaturePad signaturePad = findViewById(R.id.signaturePad);
            sig = signaturePad.getSignatureBitmap();

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            sig.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            intent.putExtra("sig", byteArray);
        }
        */

        startActivity(intent);
    }

    /*
    public void openSignatureFrame() {

        View signatureFrame = (View) findViewById(R.id.signatureFrame);
        signatureFrame.setVisibility(View.VISIBLE);
    }
     */


}